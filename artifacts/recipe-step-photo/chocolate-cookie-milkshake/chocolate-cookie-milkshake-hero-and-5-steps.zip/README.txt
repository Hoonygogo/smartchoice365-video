Smart Meals 365 chocolate cookie milkshake. One hero and five individual stages, original 1536x1024 JPEGs.
Recipe: https://smartc365.com/guides/smart-dinner-chocolate-cookie-milkshake-ko
