Smart Meals 365 - Lemon Herb Chickpea Couscous: hero.jpg and step-01.jpg through step-06.jpg, original 1536x1024 photographs. Not deployed to live website.
