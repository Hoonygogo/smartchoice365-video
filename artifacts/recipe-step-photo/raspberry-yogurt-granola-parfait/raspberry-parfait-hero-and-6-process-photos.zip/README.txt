Smart Meals 365 - Raspberry Yoghurt Granola Parfait
One hero and six independent process photos, 1536x1024 each, KO/EN same set.
The order is hero, step-01 to step-06. Not yet published to production website.
