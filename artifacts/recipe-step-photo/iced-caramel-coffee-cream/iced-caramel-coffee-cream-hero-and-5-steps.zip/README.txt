SMART MEALS 365 / 아이스 캐러멜 크림 커피
Representative hero 1 + five separate original step photographs (1536 x 1024 JPEG).
두 잔 레시피: 식힌 에스프레소 80ml, 우유 260ml, 캐러멜 시럽 30ml, 얼음 160g, 휘핑크림 45g.
step-01 espresso; step-02 ice; step-03 caramel+milk; step-04 espresso layers; step-05 whipped cream.
Unlike earlier progress-only packages, this ZIP contains ALL 6 approved original photos.
Published recipe: https://smartc365.com/guides/smart-dinner-iced-caramel-coffee-cream-ko
