SMART MEALS 365 — 아이스 말차 밀크 라테
대표사진 1장 + 과정사진 5장 (각각 1536 x 1024)
우리 홈페이지 원래 대표사진은 그대로 유지됩니다.
이 ZIP의 hero.jpg는 추가 제작한 대안 대표사진입니다.
Steps 1–5 appear on both KO/EN recipe pages.
Ingredient contract: matcha 6g, warm water 70ml, milk 320ml, maple syrup 15ml, ice 140g (2 glasses).
There are no duplicate step photos, collages or upscaled thumbnails in this bundle.
