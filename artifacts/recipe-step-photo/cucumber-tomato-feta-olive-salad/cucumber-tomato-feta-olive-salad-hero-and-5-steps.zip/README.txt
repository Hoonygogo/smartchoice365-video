SMART MEALS 365 / 오이 토마토 페타 올리브 샐러드
Representative hero 1 + five separate cooking-stage images, all 1536x1024 JPEGs.
Recipe for 2: Lebanese cucumber 180g; cherry tomatoes 180g; feta 70g; pitted Kalamata olives 45g; red onion 50g; olive oil 15ml; lemon juice 10ml; oregano 2g; black pepper 1g.
No mint, parsley, leafy greens, added salt or extra dressing.
Each numbered file maps directly to the current KO/EN original cooking step.
Public recipe: https://smartc365.com/guides/smart-dinner-cucumber-tomato-feta-olive-salad-ko
